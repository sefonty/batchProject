OS Project 1 - Batch Project

Team Number:
14

Student Contributers:
Names:                  Net IDs:
Ran (Nick) Jiang        rxj131530
Scott E. Fontenrosa     sef100020
Akash Chaturvedi        axc144430
Debaspreet Chowdhury    dxc141530
Sukmin Kang             sxk143731

Included on this USB drive:
1) source code and other development artifacts
2) Word and Text formats of this README file
3) Executable JAR (batchProject.jar) containing the processor application
    --> executable from command line:
        java -jar batchProject.java (working directory)\(.XML for batch)

        NOTE: use forward or back slash according to your OS environment